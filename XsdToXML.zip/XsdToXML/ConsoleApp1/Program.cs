﻿using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Schema;

// Localização do arquivo XSD
string xsdFilePath = @$"{AppContext.BaseDirectory}/files/correios.xsd";

// Localização do arquivo XML de saída
string xmlOutputPath = @$"{AppContext.BaseDirectory}/output/correios.xml";

// Carregar o esquema XSD
XmlSchemaSet schemaSet = new XmlSchemaSet();
string esquema = "versao_arquivo";
//string esquema = "urn:bvmf.234.01.xsd";
schemaSet.Add(esquema, xsdFilePath);
schemaSet.Compile();

// Criar um XmlWriter para escrever o arquivo XML
XmlWriterSettings settings = new XmlWriterSettings
{
    Indent = true,
    IndentChars = "\t",
    NewLineOnAttributes = false
};

using (XmlWriter writer = XmlWriter.Create(xmlOutputPath, settings))
{
    // Iniciar o documento XML
    writer.WriteStartDocument();
    writer.WriteStartElement("Document", esquema);

    // Processar cada esquema no conjunto de esquemas
    foreach (XmlSchema schema in schemaSet.Schemas())
    {
        // Processar cada elemento global no esquema
        foreach (XmlSchemaElement element in schema.Elements.Values)
        {
            
                // Escreve o elemento "Document" apenas uma vez
                WriteElement(writer, element, schemaSet);
 
        }
    }
    // Fechar o elemento "Document"
    writer.WriteEndElement();
    // Finalizar o documento XML
    writer.WriteEndDocument();
}

Console.WriteLine($"XML gerado com sucesso em: {xmlOutputPath}");

void WriteElement(XmlWriter writer, XmlSchemaElement element, XmlSchemaSet schemaSet)
{
    if (element.SchemaTypeName != null && !element.SchemaTypeName.IsEmpty)
    {
        // Se o elemento se referir a um tipo simples, escreva um valor de exemplo
        XmlSchemaType schemaType = schemaSet.GlobalTypes[element.SchemaTypeName] as XmlSchemaType;

        if (schemaType is XmlSchemaSimpleType)
        {
            writer.WriteStartElement(element.QualifiedName.Name, element.QualifiedName.Namespace);
            writer.WriteString("exampleValue"); // Substitua por um valor de exemplo adequado
            writer.WriteEndElement();
        }
        // Se o elemento se referir a um tipo complexo, chame WriteComplexType
        else if (schemaType is XmlSchemaComplexType complexType)
        {
            WriteComplexType(writer, complexType, schemaSet, element.QualifiedName.Name, element.QualifiedName.Namespace);
        }
    }
    else
    {
        // Se o elemento tiver um tipo inline, processe-o diretamente
        if (element.ElementSchemaType is XmlSchemaComplexType complexType)
        {
            WriteComplexType(writer, complexType, schemaSet, element.QualifiedName.Name, element.QualifiedName.Namespace);
        }
        else if (element.ElementSchemaType is XmlSchemaSimpleType simpleType)
        {
            WriteSimpleType(writer, simpleType, schemaSet, element.QualifiedName.Name, element.QualifiedName.Namespace);
        }
        // Se o elemento não tiver um tipo definido, escreva um elemento vazio
        else
        {
            writer.WriteStartElement(element.QualifiedName.Name, element.QualifiedName.Namespace);
            writer.WriteEndElement();
        }
        // Final do método WriteElement
    }

    void WriteComplexType(XmlWriter writer, XmlSchemaComplexType complexType, XmlSchemaSet schemaSet, string elementName, string ns)
    {
        writer.WriteStartElement(elementName, ns);

        if (complexType.Particle is XmlSchemaSequence sequence)
        {
            foreach (XmlSchemaObject item in sequence.Items)
            {
                if (item is XmlSchemaElement subElement)
                {
                    WriteElement(writer, subElement, schemaSet);
                }
            }
        }
        else if (complexType.Particle is XmlSchemaChoice choice)
        {
            // Para simplificar, estamos escrevendo o primeiro item da escolha
            XmlSchemaObject firstChoiceItem = choice.Items[0];
            if (firstChoiceItem is XmlSchemaElement choiceElement)
            {
                WriteElement(writer, choiceElement, schemaSet);
            }
        }
        // Adicione mais lógica aqui para lidar com XmlSchemaAll, XmlSchemaGroupRef, etc.

        writer.WriteEndElement(); // Fecha o elemento do tipo complexo
    }

    void WriteSimpleType(XmlWriter writer, XmlSchemaSimpleType simpleType, XmlSchemaSet schemaSet, string elementName, string ns)
    {
        writer.WriteStartElement(elementName, ns);
        // Adicione lógica para gerar valores com base no tipo simples e restrições
        writer.WriteString(GenerateExampleValue(simpleType,writer));  // Substitua por um valor de exemplo adequado
        writer.WriteEndElement();
    }

    static string GenerateExampleValue(XmlSchemaSimpleType simpleType, XmlWriter writer)
    {
        var restriction = simpleType.Content as XmlSchemaSimpleTypeRestriction;
        if (restriction != null)
        {
            int? minLength = null;
            int? maxLength = null;
            List<string> patterns = new List<string>();
            List<string> enumerations = new List<string>();

            foreach (XmlSchemaFacet facet in restriction.Facets)
            {
                if (facet is XmlSchemaMaxLengthFacet maxLengthFacet)
                {
                    maxLength = int.Parse(maxLengthFacet.Value);
                }
                else if (facet is XmlSchemaMinLengthFacet minLengthFacet)
                {
                    minLength = int.Parse(minLengthFacet.Value);
                }
                else if (facet is XmlSchemaPatternFacet patternFacet)
                {
                    patterns.Add(patternFacet.Value);
                }
                else if (facet is XmlSchemaEnumerationFacet enumerationFacet)
                {
                    enumerations.Add(enumerationFacet.Value);
                }
            }

            if (enumerations.Count > 0)
            {
                foreach (var value in enumerations)
                {
                    writer.WriteStartElement("Value");
                    writer.WriteString(value);
                    writer.WriteEndElement();
                }
                return String.Empty;
            }

            if (patterns.Count > 0)
            {
                // Gerar valor que satisfaça o primeiro padrão dinamicamente
                return GeneratePatternValue(patterns, minLength, maxLength);
            }

            int length = minLength ?? 1; // Define um comprimento padrão de 1 se minLength não for especificado
            if (maxLength.HasValue)
            {
                length = Math.Min(length, maxLength.Value);
            }

            return new string('X', length); // Gera uma string de comprimento especificado
        }

        // Valor padrão se não houver restrições específicas
        return "exampleValue";
    }

    static string GeneratePatternValue(List<string> patterns, int? minLength, int? maxLength)
    {
        // Implementação simples para gerar uma string que corresponda ao padrão dinamicamente
        // Para uma implementação completa, é necessário usar uma biblioteca de geração de strings a partir de regex
        // Aqui geramos uma string simples que se ajusta ao comprimento especificado e ao padrão

        int length = minLength ?? 1; // Define um comprimento padrão de 1 se minLength não for especificado
        if (maxLength.HasValue)
        {
            length = Math.Min(length, maxLength.Value);
        }

        // Gerar string baseada no primeiro padrão
        foreach (var pattern in patterns)
        {
            if (Regex.IsMatch(new string('1', length), pattern))
            {
                return new string('1', length); // Exemplo para dígitos
            }
            if (Regex.IsMatch(new string('a', length), pattern))
            {
                return new string('a', length); // Exemplo para letras
            }

            // Adicione mais lógica para outros tipos de padrões conforme necessário
        }
        // Se não houver correspondência, retornar um valor padrão que satisfaça minLength e maxLength
        return new string('X', length);
    }
}
